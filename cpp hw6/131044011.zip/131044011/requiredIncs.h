/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   requiredIncs.h
 * Author: ibrahim
 *
 * Created on November 8, 2016, 12:08 PM
 */

#ifndef REQUIREDINCS_H
#define REQUIREDINCS_H

#include "Computer.h"
#include "CPUProgramDyn.h"
#include "CPU.h"
#include "Memory.h"
using namespace std;
using namespace CPUProgramDynNameSpace;

#endif /* REQUIREDINCS_H */

