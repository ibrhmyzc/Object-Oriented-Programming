/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   requiredIncs.h
 * Author: ibrahim
 *
 * Created on December 27, 2016, 4:50 AM
 */

#ifndef REQUIREDINCS_H
#define REQUIREDINCS_H
#include "Bigram.h"
#include "BigramMap.h"
#include "BigramMap.cpp"
#include "BigramDyn.h"
#include "BigramDyn.cpp"
#include <iostream>
using namespace std;
using namespace BigramNamespace;
using namespace BigramMapNamespace;
using namespace BigramDynNamespace;
#endif /* REQUIREDINCS_H */

